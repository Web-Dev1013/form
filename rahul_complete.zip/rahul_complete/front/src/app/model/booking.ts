export class Booking {
    username?: string;
    useremail?: string;
    product?: string;
    location?: string;
    total_price?: number;
    date?: string;
    time?: string;
}

export class Experience {
    id?: any;
    username?: string;
    userrole?: string;
    title?: string;
    category?: string;
    shortDes?: string;
    detailDes?: string;
    location?: string;
    price?: number;
    reviews?: string;
    rating?: number;
    img1?: string;
    published?: boolean;
}

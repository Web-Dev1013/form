export class User {
    username: string = '';
    email: string ='';
    role: string ='';
    status: string='';
    sex?: string;
    birthday?: string;
    city?: string;
    street?: string;
    job?: string;
    phone?: string;
    currentPass?: string;
    newPass?: string
}
